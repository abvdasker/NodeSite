//
//  TableViewController.m
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()

- (UIColor *) makeRandomColor;

@property NSMutableArray *tableCells;   // backing dataSource
@property int selectedPeerIndex;
@property int buttonY;
@property int buttonN;
@property NSString *conRequestPeer;
@property NSMutableDictionary *thePeerList;
@end

@implementation TableViewController

@synthesize selectedPeerIndex;
@synthesize messageSession;
@synthesize userName;
@synthesize tableCells;
@synthesize buttonY;
@synthesize buttonN;
@synthesize conRequestPeer;
@synthesize thePeerList;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    tableCells = [[NSMutableArray alloc] init];
    [tableCells addObject:userName];
    int k = 777;
    thePeerList = [NSMutableDictionary dictionaryWithObject:userName forKey:[NSNumber numberWithInt:k]];
    
    messageSession = [[GKSession alloc] initWithSessionID:@"chatSession" displayName:userName sessionMode:GKSessionModePeer];
    messageSession.available = YES;
    messageSession.delegate = self;
    //messageSession.disconnectTimeout = 10;
    
    peers = [[NSMutableArray alloc] init];
}

/*- (IBAction)testSendMsg:(id)sender {
    NSLog(@"Send MSG pressed");
    [self sendMessage:nil sentText:@"Hello World@"];
}

- (void) addRow{
    
    int lastind = [thePeerList count];
    [tableCells addObject: [self numToString: lastind]];
    
    NSArray *insertIndexPaths = [NSArray arrayWithObjects:
                                 [NSIndexPath indexPathForRow:lastind inSection:0],
                                 nil];
    
    UITableView *tv = (UITableView *)self.view;
    [tv beginUpdates];
    [tv insertRowsAtIndexPaths:insertIndexPaths withRowAnimation:UITableViewRowAnimationRight];
    [tv endUpdates];
}*/

-(void) addPeerRow: (NSString *)name {
    NSLog(@"name: %@", name);
    int lastind = [tableCells count];
    
    NSArray *insertIndexPaths = [NSArray arrayWithObjects:
                                 [NSIndexPath indexPathForRow:lastind inSection:0],
                                 nil];
    
    UITableView *tv = (UITableView *)self.view;
    [tv beginUpdates];
    [tableCells addObject: name];
    [tv insertRowsAtIndexPaths:insertIndexPaths withRowAnimation:UITableViewRowAnimationRight];
    [tv endUpdates];
}

-(void) removePeerRow: (NSString *)name {
    int removeIndex = [tableCells indexOfObject: name];
    NSLog(@"Index of object to remove: %d size: %d %@", removeIndex, [tableCells count], name);
    
    
    NSArray *removeIndexPaths = [NSArray arrayWithObjects:
                                 [NSIndexPath indexPathForRow:removeIndex inSection:0],
                                 nil];
    
    UITableView *tv = (UITableView *)self.view;
    
    //actual adding and removing of cells
    [tv beginUpdates];
    [tableCells removeObjectAtIndex: removeIndex];
    [tv deleteRowsAtIndexPaths:removeIndexPaths withRowAnimation:UITableViewRowAnimationLeft];
    [tv endUpdates];
}

-(void) connectToPeers:(id)sender{
    NSString *peerId = [tableCells objectAtIndex:selectedPeerIndex];
    [messageSession connectToPeer:peerId withTimeout:10];
}

-(void) sendMessage:(id)sender sentText:(NSString *)message{
    NSLog(@"within network message sending call");
    
    [messageSession sendData:[message dataUsingEncoding:NSASCIIStringEncoding] toPeers: peers withDataMode:GKSendDataReliable error:nil];
}
/*------------- stuff for GKSessionDelegate --------------- */


-(void) receiveData:(NSData *) data fromPeer:(NSString *)peer inSession: (GKSession *)session context:(void *) context {
    NSString *incoming = [[NSString alloc] initWithData: data encoding:NSASCIIStringEncoding];
    NSLog(@"did get data");
    /*
     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message Received" message:incoming delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
     code for alert upon receipt of data
     */
    [chatter incomingText:self receivedText:incoming];
}

-(void)session:(GKSession *)session peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state{
    
    /*NSLog(@"peer name? %@", [session displayNameForPeer: peerID]);
    prints name of peer*/
    switch (state) {
        case GKPeerStateAvailable:
        {
            [thePeerList setValue: [session displayNameForPeer: peerID] forKey:peerID];
            [self addPeerRow: [session displayNameForPeer: peerID]];
            [session setDataReceiveHandler:self withContext:nil];
            break;
        }
        case GKPeerStateConnected:
        {
            [peers addObject:peerID];  // adds connected peer
            [self removePeerRow: [thePeerList objectForKey: peerID]];  // removes peer row

            [session setDataReceiveHandler:self withContext:nil];
            
            double delayInSeconds = 0.33;
            
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                [self performSegueWithIdentifier:@"toChatSegue" sender: self];
                //code to be executed on the main queue after delay
            });

            return;
            break;
        }
        case GKPeerStateDisconnected:
        {
            [chatter backNav];
            [peers removeObject:peerID];
            
            NSString *str = [NSString stringWithFormat: @"Disconnected from %@", [messageSession displayNameForPeer: peerID]];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Disconnected" message: str delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
            alert.delegate = self;
            [alert show];
            //[self removePeerRow: [thePeerList objectForKey: peerID]];
            //[thePeerList removeObjectForKey: peerID];
            [session setDataReceiveHandler:self withContext:nil];
            break;
        }
            
        case GKPeerStateUnavailable:
        {
            //[avPeers removeObject:peerID];
            [self removePeerRow: [thePeerList objectForKey: peerID]];
            if ([thePeerList objectForKey:peerID]) {
                [thePeerList removeObjectForKey: peerID];
            }
            if ([peers containsObject:peerID]) {
                [peers removeObject: peerID];
            }
            [session setDataReceiveHandler:self withContext:nil];
            
            break;
        }
    }
}

-(void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *) peerID {
    conRequestPeer = peerID;
    NSString *str = [NSString stringWithFormat: @"Would you like to connect with %@?", [session displayNameForPeer: peerID]];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Connection Request" message: str delegate: self cancelButtonTitle: nil otherButtonTitles: nil];
    buttonY = [alert addButtonWithTitle: @"Yes"];
    buttonN = [alert addButtonWithTitle: @"No"];
    alert.delegate = self;
    
    [alert show];
}

-(void) updateAvailable: (NSString *) lastConnect{
    NSString *lastpID = [[thePeerList allKeysForObject:lastConnect] objectAtIndex: 0];
    NSArray *availables = [messageSession peersWithConnectionState:GKPeerStateAvailable];
    //NSArray *connecteds = [messageSession peersWithConnectionState:GKPeerStateConnected];
    for (NSString* pID in availables) {
        if ([lastpID isEqualToString:pID]) {
            return;
        }
    }
    [thePeerList removeObjectForKey: lastpID];
}
/*------------- end of stuff for GKSessionDelegate --------------- */


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

/* ---------------------- UITableView datasource stuff--------------------*/

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    return [tableCells count];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        cell.backgroundColor = [UIColor blackColor];
        [cell setUserInteractionEnabled:NO];
        NSLog(@"drew first cell");
    } else {
        NSLog(@"drew cell not first");
        cell.backgroundColor = [UIColor whiteColor];
        cell.textColor = [UIColor blackColor];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = [tableCells objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor whiteColor];
    return cell;
}

/* ----------------------- End of UITableViewDatasource stuff -------------------- */

// ------------- Beginning of AlertViewDelegate stuff ----------

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == buttonY) {
        [messageSession acceptConnectionFromPeer:conRequestPeer error:nil];
        //[messageSession connectToPeer:conRequestPeer withTimeout:20];
    } else if (buttonIndex == buttonN) {
        [messageSession denyConnectionFromPeer:conRequestPeer];
        [messageSession cancelConnectToPeer:conRequestPeer];
    }
}

// ------------- End of AlertViewDelegate stuff -------------

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"ROW SELECTED");
    //[self performSegueWithIdentifier: @"toChatSegue" sender: self];
    selectedPeerIndex = indexPath.row;
    [messageSession connectToPeer: [[thePeerList allKeysForObject:[tableCells objectAtIndex: selectedPeerIndex]] objectAtIndex: 0] withTimeout:20];
    //[self connectToPeers:[tableCells objectAtIndex:selectedPeerIndex]];
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    [self resignFirstResponder];
    NSLog(@"PREPARE FOR SEGUE");
    if ([[segue identifier] isEqualToString:@"toChatSegue"]) {
        NSLog(@"INSIDE IF, PREPARE FOR CHAT SEGUE");
        chatter = (ChatController*)segue.destinationViewController;
        chatter.userName = self.userName;
        chatter.peerName = [thePeerList objectForKey:[peers objectAtIndex:0]];
        chatter.theParent = self;
        //chatter.delegate = self;
    }
}

/*- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 NSLog(@"PREPARE FOR SEGUE");
 if ([[segue identifier] isEqualToString:@"toChatSegue"]) {
 NSLog(@"INSIDE IF, PREPARE FOR SEGUE");
 ChatController *targetVC = (ChatController*)segue.destinationViewController;
 targetVC.userName = self.userName;
 targetVC.peerName = [tableCells objectAtIndex:selectedPeerIndex];
 }
 // Navigation logic may go here. Create and push another view controller.
 
 <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
 // ...
 // Pass the selected object to the new view controller.
 [self.navigationController pushViewController:detailViewController animated:YES];
 
 }*/

@end
