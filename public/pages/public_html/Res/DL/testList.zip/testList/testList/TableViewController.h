//
//  TableViewController.h
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GameKit/GameKit.h>
#import "ChatController.h"
@class ChatController;  // avoids import loop

@interface TableViewController : UITableViewController <GKSessionDelegate, UIAlertViewDelegate, UITextFieldDelegate> {
    GKSession *messageSession;
    
    NSMutableArray *peers;
    ChatController *chatter;
    
}

@property (copy, nonatomic) NSString *userName;
@property (retain) GKSession *messageSession;
@property BOOL fromChat;

- (void) connectToPeers:(id) sender;
- (void) sendMessage:(id) sender sentText:(NSString *) message;
- (void) updateAvailable: (NSString *) lastConnect;

@end