//
//  AppDelegate.h
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
