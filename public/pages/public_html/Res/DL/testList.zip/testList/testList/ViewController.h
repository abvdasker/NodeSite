//
//  ViewController.h
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewController.h"
#import "ChatController.h"

@interface ViewController : UIViewController <UITextFieldDelegate>

@property (copy, nonatomic) NSString *userName;

@end