//
//  ChatController.m
//  testList
//
//  Created by Hal Rogers 13 on 10/2/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import "ChatController.h"

@interface ChatController ()
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UINavigationBar *titleBar;
@property (weak, nonatomic) IBOutlet UITextView *logBox;
@property (weak, nonatomic) IBOutlet UITextField *msgInputBox;
@property UIBarButtonItem *theBackButton;
- (IBAction)sendPress:(id)sender;
//- (IBAction)goBack:(id)sender;

@end

@implementation ChatController
@synthesize msgInputBox;
@synthesize userName;
@synthesize peerName;
@synthesize logBox;
@synthesize titleBar;
@synthesize theBackButton;
@synthesize theParent;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    //[super viewDidLoad];
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    /*UIButton* backButton = [UIButton buttonWithType:101]; // left-pointing shape!
    [backButton addTarget:self action:@selector(goBack:) forControlEvents:UIControlEventTouchUpInside];
    [backButton setTitle:@"Back" forState:UIControlStateNormal];
    
    // create button item -- possible because UIButton subclasses UIView!
    UIBarButtonItem* backItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    
    // add to toolbar, or to a navbar (you should only have one of these!)
    [titleBar setItems:[NSArray arrayWithObject:backItem]];
    theBackButton = backItem;
    //navItem.leftBarButtonItem = backItem;*/
    
    //theParent = (TableViewController *) self.parentViewController;
    
    //NSString *word = [self startSearchAndResign] ? @"TRUE" : @"FALSE";
    //NSLog([NSString stringWithFormat:@"did find it %@?", word]);
    [self.theParent.parentViewController.view endEditing:YES];
    titleBar.topItem.title = [NSString stringWithFormat:@"Chat with %@", peerName];
    //[logBox setText: ];
    NSLog(@"new view: %@ %@", userName, peerName);
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{ 
    [self setMsgInputBox:nil];
    [self setTitleBar:nil];
    [self setLogBox:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL) textFieldShouldReturn: (UITextField *) theTextField { 
    if (theTextField == self.msgInputBox){
        //[self.view endEditing:YES];
        [theTextField resignFirstResponder];
    }
    return YES;
}
-(void) incomingText:(id)sender receivedText:(NSString *)text {
    NSLog(@"received message");
    [self displayTextFrom:peerName outputText:text];
}

-(void)outgoingText{
    NSLog(@"outgoing text method called");
    NSString *message = msgInputBox.text;
    msgInputBox.text = @"";
    [self displayTextFrom:@"Me" outputText:message];
    [theParent sendMessage: self sentText:message];
}

-(void) displayTextFrom:(NSString *)person outputText:(NSString *) text {
    //NSDate *theDate = [NSDate date];  FILL OUT DATE METHOD
    if (![text isEqualToString:@""]) {
        logBox.text = [logBox.text stringByAppendingString:[NSString stringWithFormat:@"%@: %@ \n \n", person, text]];
    }
}

- (IBAction)sendPress:(id)sender {
    NSLog(@"send text button pressed");
    [self outgoingText];
    AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
}

- (IBAction)goBack:(id)sender {
    NSLog(@"back button pressed successfully");
    
    [theParent.messageSession disconnectFromAllPeers];   // eventually calls backNav
}

- (void) backNav {
    NSLog(@"backNav called successfully");
    [theParent.messageSession disconnectFromAllPeers];
    [self dismissModalViewControllerAnimated:YES];
    [theParent updateAvailable:peerName];
}
@end
