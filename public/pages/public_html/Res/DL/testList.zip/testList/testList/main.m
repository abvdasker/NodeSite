//
//  main.m
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
