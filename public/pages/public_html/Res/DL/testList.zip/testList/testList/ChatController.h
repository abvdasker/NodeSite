//
//  ChatController.h
//  testList
//
//  Created by Hal Rogers 13 on 10/2/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>
#import "TableViewController.h"
@class TableViewController;   // avoids import loop

@interface ChatController : UIViewController <UITextFieldDelegate> {
}

@property NSString *userName;
@property NSString *peerName;
@property TableViewController *theParent;
- (void) incomingText: (id) sender receivedText:(NSString *) text;
- (void) backNav;

@end