//
//  ViewController.m
//  testList
//
//  Created by Hal Rogers on 10/1/12.
//  Copyright (c) 2012 Hal Rogers. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameField;
- (IBAction) connectButtonPress:(id)sender;

@end

@implementation ViewController
@synthesize userNameField;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setUserNameField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (BOOL) textFieldShouldReturn: (UITextField *) theTextField {
    if (theTextField == self.userNameField){
        [theTextField resignFirstResponder];
    }
    return YES;
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSLog(@"PREPARE FOR SEGUE");
    if ([[segue identifier] isEqualToString:@"toListSegue"]) {
        TableViewController *targetVC = (TableViewController*)segue.destinationViewController;
        targetVC.userName = self.userName;
    }
}

- (IBAction) connectButtonPress:(id)sender {
    NSLog(@"BUTTON PRESSED");
    if (![userNameField.text isEqualToString:@""]){
        self.userName = self.userNameField.text;
        [self performSegueWithIdentifier: @"toListSegue" sender: self];
    }
}
@end
