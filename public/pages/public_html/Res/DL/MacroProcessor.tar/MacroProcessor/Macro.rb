class Macro

  attr_accessor :macroName, :arguments, :innerText, :labels, :macroCount, :currentMacro

  @macroCount
  @currentMacro

  @macroName
  @arguments
  @labels
  @innerText
  def initialize (name, arg)
    @macroCount = 0
    @currentMacro = nil

    @macroName = name
    @arguments = arg
    @innerText = Array.new
    @labels = Hash.new
  end

end