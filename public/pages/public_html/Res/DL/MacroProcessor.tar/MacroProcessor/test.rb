h = Hash.new
h["first"] = "I'm first"
		
puts h