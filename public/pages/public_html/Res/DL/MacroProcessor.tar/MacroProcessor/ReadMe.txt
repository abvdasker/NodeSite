MACROPROCESSOR:
____________________________________

Basics:
- to run the Macroprocessor:
	ruby MacroProcessor.rb <inputfile> <outputfile>
- All code must be preceded by the ".Code" tag

______________________________

Defining Macros:
- Macros are defined using the "MACRO" keyword followed by the Macros' name followed by the macro's arguments
- After the first line containing the macro name, the following lines will be the contents of the macro
- the macro definition ends with the keyword "ENDMACRO"

Example:
MACRO COPYANDHALT
	COPY %G1 %G0
	HALT
ENDMACRO

COPYANDHALT   =>  COPY %G1 %G0
				  HALT
____________________________________________

Macro Arguments/Parameters:
- Macro Arguments/Parameters are prefixed by the "$" sign
- When a macro is used, the definition's parameters (and everywhere they appear) 
	will be substituted by the arguments in the macro use

Example:
MACRO COPYBACKWARDS $X $Y
	COPY $Y $X
ENDMACRO

COPYBACKWARDS %G1 %G0   =>   COPY %G0 %G1

__________________________________________________

Internal Macro Definitions:
- Macros can be defined within other macros
- a macro defined within a macro can only be used after the containing macro has been called at least once

Example:
MACRO COPYBACKWARDS $X $Y
	COPY $Y $X
	
	MACRO COPYANDHALT
		COPY %G1 %G0
		HALT
	ENDMACRO
	
ENDMACRO

COPYANDHALT            => won't work
COPYBACKWARDS %G1 %G0  => COPY %G0 %G1
COPYANDHALT            => COPY %G1 %G0
                          HALT
                          
Example2:
MACRO COPYBACKWARDS $X $Y
	COPY $Y $X
	
	MACRO COPYANDHALT $Z
		COPY %G4 $Z
		HALT
	ENDMACRO
	
	COPYANDHALT $X
	
ENDMACRO

COPYBACKWARDS %G0 %G1           =>   COPY %G1 %G0
                                     COPY %G4 %G0
                                     HALT
                                     
_________________________________

IF/ELSE and WHILE:
- The macroprocessor allows for the use of two basic code block structures
- A code block begins with a conditional statement defining the codeblock, two
	arguments to be compared, and a comparator, which goes between them
- The code block terminates with the keyword "END"
- Code blocks may be used within macros

Example:
IF %G0 LT %G1                   =>        BLT +IF0 %G0 %G1
	SUBUS %G1 %G1 %G0                     JUMP +ELSE0 
ELSE                               	 IF0:
	SUBUS %G0 %G0 %G1                     SUBUS %G1 %G1 %G0
END                                       JUMP +END0
                                     ELSE0:
                                          SUBUS %G0 %G0 %G1
                                     END0: 
                                     
______________________________________________________

Macro Variables:
- Macro variables exist in the macroprocessor and are independent of the macro 
	in which they are defined
- Macro variables allow for a kind of global variable

Example:
MACRO COPYBACKWARDS $X $Y
	@D = 5
	COPY $Y $X
ENDMACRO
	
MACRO COPY5 $Y
	COPY $Y @D
ENDMACRO

COPY5 %G2      =>    COPY %G2 5
_______________________________________________________

Local Labels:
- labels defined using the & symbol are local to a macro and will have a number appended to
	them so that on subsequent calls of the same macro, they remain unique
	
Example:	
MACRO INFINITELOOP
&jump:
	JUMP &jump
ENDMACRO

INFINITELOOP     =>   jump0:
INFINITELOOP               JUMP +jump0
					  jump1:
					   	   JUMP +jump1

__________________________________________________________
