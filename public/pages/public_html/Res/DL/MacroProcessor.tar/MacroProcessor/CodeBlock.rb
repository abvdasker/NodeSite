class CodeBlock
  attr_accessor :label, :type, :innerText, :arg0, :arg1, :compare

  @label
  @type
  @innerText
  @compare
  @arg0
  @arg1
  def initialize(ty)
    @type = ty
    @label = ""
    @innerText = ""
    @compare = ""

  end
end