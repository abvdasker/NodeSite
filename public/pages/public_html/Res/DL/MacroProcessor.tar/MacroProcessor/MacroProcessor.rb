require "Macro.rb"
require "CodeBlock.rb"

class MacroProcessor
  attr_accessor :input, :output, :macroTable, :blockStack, :mode

  @@keyWords = ["IF", "ELSE", "WHILE", "END"]

  @@basicNames = ["NOOP", "NOT", "COPY", "COPYB", "AND",
    "OR", "XOR", "ADD", "ADDUS", "SUB", "SUBUS", "MUL", "MULUS",
    "DMUL", "DIV", "MOD", "SHFTL", "SHFTR", "JUMP", "CALL", "JUMPMD",
    "BEQ", "BNEQ", "BGT", "BGTE", "BLT", "BLTE", "SETTBR", "SETIBR",
    "SETPTR", "GETCLK", "SETALM", "SYSC", "HALT"];

  @@blockLabels

  @input
  @output
  @macroTable
  @macroVars
  @blockStack
  @mode
  @codeState

  @isCommentLine

  def initialize(inname, outname)
    @macroTable = Hash.new
    @macroVars = Hash.new
    @blockStack = Array.new
    @@blockLabels = Hash.new

    @mode = "exterior"
    @codeState = "new"

    if File.file?(inname)
      @input = File.new(inname, "r+")
      @output = File.new(outname, "w+")
    else
      puts "INPUT FILE DOES NOT EXIST"
    end
  end

  def self.basicNames
    @@basicNames
  end

  def self.keyWords
    @@keyWords
  end

  def self.blockLabels
    @@blockLabels
  end

  #called when a macro use is found and treats base code as a single macro call
  def expand (macro, args)
    buffer = ""
    buffer = printOut(buffer, ";;; ---- BEGIN MACRO "+macro.macroName+ "\n")

    if args.length == macro.arguments.length
      macro.innerText.each do |innerLine|
        arr = innerLine.split
        first = arr.shift
        if first
          buffer = chompComment(buffer, innerLine)
          unless @isCommentLine
            if isTag?(first)
              buffer = chompTagLine(buffer, first, arr)
            elsif @codeState != ".Code"
              buffer = chompLine(buffer, innerLine)
            else
              buffer = chompValid(macro, first, buffer, arr, args, innerLine)
            end
          end
        end
      end
    end
    buffer = printOut(buffer, ";;; ---- END MACRO "+macro.macroName)
    buffer
  end

  #processes a commented line -- just copies it to output buffer
  def chompComment (buffer, wholeLine)
    if wholeLine[0..1] == ";;"
      buffer = printOut(buffer, wholeLine)
      @isCommentLine = true
    else
      @isCommentLine = false
    end

    return buffer
  end

  #processes a line beginning with a tag
  def chompTagLine(buffer, first, arr)
    @codeState = first
    buffer = printOut(buffer, first+"\n")
    first = arr.shift
    return buffer
  end

  #processes a line when not within the .Code tag
  def chompLine(buffer, innerLine)
    buffer = printOut(buffer, innerLine+"\n")
    return buffer
  end

  #chomps a line within a .Code section
  def chompValid(macro, first, buffer, arr, args, innerLine)
    if macro.macroCount == 0 and isLabel?(first)
      buffer = chompLabelLine(macro, buffer, first, arr)
    end
    if macro.macroCount == 0 and isVar?(first)
      #adds macro variable
      @macroVars[first] = arr[arr.length-1]
    elsif macro.macroCount == 0 and @@keyWords.include? first  #beginning of branch keyword thing\
      buffer = chompCodeBlockLine(macro, buffer, first, arr, args)
    elsif first == "ENDMACRO"
      chompEndMacroLine(macro, innerLine)
    elsif first == "MACRO"
      chompStartMacroLine(macro, arr, innerLine)
    elsif macro.macroCount > 0
      chompInnerMacroLine(macro, innerLine)
    elsif @@basicNames.include? first  #simple instruction in macro def
      buffer = chompSimpleLine(buffer, first, arr, macro, args)
    elsif @macroTable.has_key? first #macro call inside macro expansion
      #recursive expansion; the magic
      #processes a macro usage
      fixedarguments = replaceVars(macro, arr, args)
      buffer = printOut(buffer, expand(@macroTable[first], fixedarguments))
    end
    if macro.macroCount < 1
      appendLine = ""
      if buffer != ""
        appendLine = "\n"
      end
      buffer = printOut(buffer, appendLine)
    end
    return buffer
  end

  #chomps a line beginning with a label
  def chompLabelLine(macro, buffer, first, arr)
    while first and isLabel?(first)
      if (first[0] == "&")
        first = first[0..first.length-2]
        first.slice!(0)
        buffer = printOut(buffer, generateLabel(macro, first)+":")
      else
        buffer = printOut(buffer, first)
      end
      first = arr.shift
    end
    return buffer
  end

  #chomps a line with a code block keyword
  def chompCodeBlockLine(macro, buffer, first, arr, args)
    case first
    when "IF" then
      ifblock = CodeBlock.new("IF") # make new block
      parseBlockArgs(macro, ifblock, arr, args)
      ifblock.label = generateBlockLabel("IF")
      ifblock.innerText  += (ifblock.label.to_s) +": \n"
      @blockStack.push(ifblock)
      @mode = "interior"
    when "ELSE" then
      elseblock = CodeBlock.new("ELSE")
      #parse arguments prepend branch to lastif.label
      elseblock.label = generateBlockLabel("ELSE")
      elseblock.innerText += (elseblock.label) +": \n"
      @blockStack.push(elseblock)
      @mode = "interior"
    when "WHILE" then
      whileblock = CodeBlock.new("WHILE")
      parseBlockArgs(macro, whileblock, arr, args)
      whileblock.label = generateBlockLabel("WHILE")
      whileblock.innerText+= (whileblock.label) + ": \n"
      @blockStack.push(whileblock)
      @mode = "interior"
    when "END" then
      endlabel = generateBlockLabel("END")
      outBlock = ""
      if @blockStack.last.type == "ELSE" and @blockStack[@blockStack.length-2].type == "IF"
        elseblock = @blockStack.pop
        ifblock = @blockStack.pop
        ifblock.innerText.prepend("JUMP +"+elseblock.label+"\n")
        ifblock.innerText +="JUMP +"+endlabel+"\n"
        ifblock.innerText += elseblock.innerText
        ifblock.innerText += endlabel +":"
        ifblock.innerText.prepend(ifblock.compare + " +"+ifblock.label+" "+ifblock.arg0+" "+ifblock.arg1+"\n")
        outBlock = ifblock.innerText
      elsif @blockStack.last.type == "IF"
        ifblock = @blockStack.pop
        ifblock.innerText.prepend("JUMP +"+endlabel+"\n")
        ifblock.innerText += endlabel +":"
        ifblock.innerText.prepend(ifblock.compare + " +"+ifblock.label+" "+ifblock.arg0+" "+ifblock.arg1+"\n")
        #parse arguments and prepend branch to
        outBlock = ifblock.innerText
      elsif @blockStack.last.type == "WHILE"
        whileblock = @blockStack.pop
        whileblock.innerText  += whileblock.compare + " +"+whileblock.label+" "+whileblock.arg0+" "+whileblock.arg1+"\n"
        #parse arguments and whileblock.append branch to whileblock.label
        outBlock = whileblock.innerText
      end
      #add codeblock to buffer
      if @blockStack.length == 0
        @mode="exterior"
      end
      buffer = printOut(buffer, outBlock)
    end
    return buffer
  end

  #processes a line beginning with the ENDMACRO keyword
  def chompEndMacroLine (macro, innerLine)
    if macro.currentMacro and macro.macroCount == 1
      @macroTable[macro.currentMacro.macroName] = macro.currentMacro
    elsif macro.currentMacro
      macro.currentMacro.innerText.push(innerLine)
    end
    macro.macroCount -= 1
  end

  #processes a line beginning with the MACRO keyword
  def chompStartMacroLine(macro, arr, innerLine)
    if macro.macroCount == 0
      name = arr.shift
      unless @@basicNames.include? name
        parameters = Array.new
        while !arr.empty?
          parameters.push(arr.shift)
        end
        macro.currentMacro = Macro.new(name, parameters)
      else
      end
    else
      macro.currentMacro.innerText.push(innerLine)
    end
    macro.macroCount += 1
  end

  #processes a line between MACRO and ENDMACRO keywords
  def chompInnerMacroLine(macro, innerLine)
    macro.currentMacro.innerText.push(innerLine)
  end

  #processes a line for a non-macro assembly command
  def chompSimpleLine(buffer, first, arr, macro, args)
    buffer = printOut(buffer, first + " ")
    arr.each do |arg|
      argString = parseArgument(macro, arg, args)
      buffer = printOut(buffer, argString)
    end
    return buffer
  end

  def parseBlockArgs (macro, block, stmargs, callargs)
    block.compare = "B"+stmargs[1]

    block.arg0 = parseArgument(macro, stmargs[0], callargs)
    block.arg1 = parseArgument(macro, stmargs[2], callargs)
  end

  def replaceVars(macro, terms, params)
    #macro is macro being expanded, params is list of arguments with macro current expansion
    #terms are the arguments for macro about to be expanded: return array of raw registers
    altered = Array.new
    terms.each do |term|
      prefix = getPrefix!(term)
      i = macro.arguments.index(term)
      if i
        if term[0] == "$"
          altered.push(prefix+params[i].to_s)
        end
      elsif term[0] == "&"
        term.slice!(0)
        if macro.labels.has_key? term
          altered.push("+" + arg + macro.labels[term].to_s)
        end
      elsif isVar?(term) and @macroVars.has_key? arg
        altered.push(@macroVars[term])
      else
        altered.push(term)
      end
    end
    return altered
  end

  def parseArgument(macro, arg, args)
    outstr = ""
    prefix = getPrefix!(arg)

    i = macro.arguments.index(arg)
    if i # matches a macro argument
      if arg[0] == "$"
        outstr += prefix+args[i].to_s
      end
    elsif arg[0] == "&"
      arg.slice!(0)
      if macro.labels.has_key? arg
        # label used is defined within a macro definition
        outstr += "+"+ arg + macro.labels[arg].to_s
      end
    elsif isVar?(arg) and @macroVars.has_key? arg
      outstr += @macroVars[arg]
    else
      outstr += prefix+arg
    end
    outstr += " "
    return outstr
  end

  def printOut(buffer, str)
    if @mode != "exterior"
      @blockStack.last.innerText += str
      return buffer
    else
      buffer += str
      return buffer
    end
  end

  def getPrefix!(str)
    prefix = ""
    if str[0] == "*"
      prefix += str.slice!(0)
    end

    if str[0] == "+"
      prefix += str.slice!(0)
    end
    return prefix
  end

  def generateLabel(macro, lab)
    if macro.labels.has_key? lab
      macro.labels[lab] += 1
    else
      macro.labels[lab] = 0
    end
    s = lab + macro.labels[lab].to_s
    return s
  end

  def generateBlockLabel(lab)
    if @@blockLabels.has_key? lab
      @@blockLabels[lab] += 1
    else
      @@blockLabels[lab] = 0
    end
    s = lab + @@blockLabels[lab].to_s
    return s
  end

  def write(str)
    @output.write(str)
  end

  def isLabel? (str)
    return str.end_with?(":")
  end

  def isTag? (str)
    return str.start_with?(".")
  end

  def isVar?(str)
    return str.start_with?("@")
  end
end

# main

macTable = Hash.new

outputName = ARGV[1]
inputName = ARGV[0]

processor = MacroProcessor.new(inputName, outputName)

main = Macro.new("main", Array.new)
processor.input.each_line do |line|
  main.innerText.push(line)
end

#treats file like a macro expansion
processor.write(processor.expand(main,Array.new))