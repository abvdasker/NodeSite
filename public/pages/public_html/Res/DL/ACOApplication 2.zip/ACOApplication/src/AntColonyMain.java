public class AntColonyMain {
	
	//invokelater to update GUI

	public static void main(String[] args){
		System.out.println("Hello World from Eclipse!");
		Thread gap = new GeneralizedAssignmentProblem();
		gap.start();
	}
}
