package antGraphics;

public class AntMode {
	
	public int m;
	
	public AntMode(int j) {
		m = j;
	}
	
}
