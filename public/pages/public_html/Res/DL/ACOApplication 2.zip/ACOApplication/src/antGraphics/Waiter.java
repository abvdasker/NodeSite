package antGraphics;


public class Waiter {

	int lnum;
	
	public Waiter(int i) {
		lnum = i;
	}
	
}
